﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace E_GOVForMOA
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional },
                namespaces: new[] { "E_GOVForMOA.Controllers" }
            );

            routes.MapRoute("GetDocListByCargoTypeId",
                     "Baytarliq1/GetDocListByCargoTypeId/",
                     new { controller = "Baytarliq1", action = "GetDocListByCargoTypeId" },
                     new[] { "E_GOVForMOA.Controllers" });

            routes.MapRoute("Get2LevelDrugsById",
                         "Baytarliq1/Get2LevelDrugsById/",
                         new { controller = "Baytarliq1", action = "Get2LevelDrugsById" },
                         new[] { "E_GOVForMOA.Controllers" });

            routes.MapRoute("Get3LevelDrugsById",
                        "Baytarliq1/Get3LevelDrugsById/",
                        new { controller = "Baytarliq1", action = "Get3LevelDrugsById" },
                        new[] { "E_GOVForMOA.Controllers" });

            routes.MapRoute("Get4LevelDrugsById",
                        "Baytarliq1/Get4LevelDrugsById/",
                        new { controller = "Baytarliq1", action = "Get4LevelDrugsById" },
                        new[] { "E_GOVForMOA.Controllers" });



            routes.MapRoute("Get2LevelDrugsByIdForBaytarliq2",
                        "Baytarliq2/Get2LevelDrugsById/",
                        new { controller = "Baytarliq1", action = "Get2LevelDrugsById" },
                        new[] { "E_GOVForMOA.Controllers" });

            routes.MapRoute("Get3LevelDrugsByIdForBaytarliq2",
                        "Baytarliq2/Get3LevelDrugsById/",
                        new { controller = "Baytarliq1", action = "Get3LevelDrugsById" },
                        new[] { "E_GOVForMOA.Controllers" });

            routes.MapRoute("Get4LevelDrugsByIdForBaytarliq2",
                        "Baytarliq2/Get4LevelDrugsById/",
                        new { controller = "Baytarliq1", action = "Get4LevelDrugsById" },
                        new[] { "E_GOVForMOA.Controllers" });


            routes.MapRoute("GetTitleByScreenId",
                            "DynamicPageContent/GetTitleByScreenId/",
                            new { controller = "DynamicPageContent", action = "GetTitleByScreenId" },
                            new[] { "E_GOVForMOA.Controllers" });

            routes.MapRoute("deletePageContent",
                         "DynamicPageContent/deletePageContent/",
                         new { controller = "DynamicPageContent", action = "deletePageContent" },
                         new[] { "E_GOVForMOA.Controllers" });

            routes.MapRoute("loginAdmin",
                       "Admin/Account/Login",
                       new { controller = "Account", action = "Login" },
                       new[] { "E_GOVForMOA.Areas.Admin.Controllers" });


            routes.MapRoute("GetAppTypeCode",
                            "Application/GetAppTypeCode/",
                            new { controller = "Application", action = "GetAppTypeCode" },
                            new[] { "E_GOVForMOA.Controllers" });
            routes.MapRoute("Get2LevelTechnicsById",
                        "Lizinq2/Get2LevelTechnicsById/",
                        new { controller = "Lizinq2", action = "Get2LevelTechnicsById" },
                        new[] { "E_GOVForMOA.Controllers" });

            routes.MapRoute("Get2Lizinq1TechnicsById",
                    "Lizinq1/Get2Lizinq1TechnicsById/",
                    new { controller = "Lizinq1", action = "Get2Lizinq1TechnicsById" },
                    new[] { "E_GOVForMOA.Controllers" });
        }
    }
}