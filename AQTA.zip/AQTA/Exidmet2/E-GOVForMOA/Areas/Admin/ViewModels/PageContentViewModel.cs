﻿using E_GOVForMOA.EGOVForMOAWbService;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace E_GOVForMOA.Areas.Admin.ViewModels
{
    public class PageContentViewModel
    {
        public PageContentViewModel()
        {
            ScrenTypes = new List<SelectListItem>();
            Tites = new List<SelectListItem>();
            _contentInPageList = new List<CONTENTLINKSINPAGE>();
        }


        [Display(Name = "Ekran/Forum")]
        public string ScreenID { get; set; }
        public IList<SelectListItem> ScrenTypes;


        [Display(Name = "Başlıq/Title")]
        public string TitleID { get; set; }
        public IList<SelectListItem> Tites;

        [Display(Name = "Link Aciklama")]
        public string description { get; set; }

        public IEnumerable<CONTENTLINKSINPAGE> _contentInPageList { get; set; }
      
    }
}