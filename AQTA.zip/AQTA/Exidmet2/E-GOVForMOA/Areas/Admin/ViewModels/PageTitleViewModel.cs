﻿using E_GOVForMOA.EGOVForMOAWbService;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace E_GOVForMOA.Areas.Admin.ViewModels
{
    public class PageTitleViewModel
    {

     
      public PageTitleViewModel() {

          _titleInPage = new TITLESINPAGE();
          _titleInPageList = new List<TITLESINPAGE>();
          ScrenTypes = new List<SelectListItem>();

      }

      [Display(Name = "Ekran/Forum")]
      public string ScreenID { get; set; }
      public IList<SelectListItem> ScrenTypes;
      public TITLESINPAGE _titleInPage { get; set; }
      public IEnumerable<TITLESINPAGE> _titleInPageList { get; set; }

    }
}