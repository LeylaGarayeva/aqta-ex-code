﻿using E_GOVForMOA.Areas.Admin.Libraries;
using E_GOVForMOA.Areas.Admin.ViewModels;
using E_GOVForMOA.EGOVForMOAWbService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace E_GOVForMOA.Areas.Admin.Controllers
{
       [LoginRequired]
    public class DynamicPageController : Controller
    {
        //
        // GET: /Admin/PageTitle/
        E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv srv = new E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv();

         
        public ActionResult Index(PageTitleViewModel pageTitleWM)
        {



           // PageTitleViewModel pageTitleWM = new PageTitleViewModel();

            pageTitleWM.ScrenTypes.Add(new SelectListItem { Text = "-Ekran seç-", Value = "9987787" });

            var sreens = srv.WS_GetScreenTypes();
            foreach (var screen in sreens)
            {
                pageTitleWM.ScrenTypes.Add(new SelectListItem()
                {

                    Text = screen.SCREEN_NAME,
                    Value = screen.GUID.ToString()
                });
            }
            pageTitleWM._titleInPageList = srv.WS_GetPageTitles();
            return View(pageTitleWM);
        }

        [HttpPost]
        public string addPageTitle(TITLESINPAGE _titleInPage)
        {
            try
            {
                PageTitleViewModel pageTitleWM = new PageTitleViewModel();
                _titleInPage.GUID = Utility.getGuid();
                _titleInPage.INSERT_DATE = Utility.getInsetDate();
                _titleInPage.STATUS = 1;
                _titleInPage.STATUSSpecified = true;



                _titleInPage.LASTUPDATED = "1";

                srv.WS_AddPageTitle(_titleInPage);


                pageTitleWM._titleInPage = _titleInPage;
                pageTitleWM._titleInPageList = srv.WS_GetPageTitles();
                return "1";
            }
            catch (Exception ex)
            {
                
               return "-1";
            }
        
        }
         
        [HttpPost]
        public string deletePageTitle(string guid)
        {
            try
            {

         
            PageTitleViewModel pageTitleWM = new PageTitleViewModel();
            TITLESINPAGE tp = new TITLESINPAGE();
         
            if (!String.IsNullOrEmpty(guid))
            {
                tp.GUID = guid;
                srv.WS_DeletePageTitle(tp);
                pageTitleWM._titleInPageList = srv.WS_GetPageTitles();
                
            }
            return "1";
            }
            catch (Exception ex)
            {

                return "-1";
            }
        }

    
    }
}
