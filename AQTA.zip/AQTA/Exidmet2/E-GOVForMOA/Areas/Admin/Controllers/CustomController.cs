﻿using E_GOVForMOA.Areas.Admin.Libraries;
using E_GOVForMOA.EGOVForMOAWbService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace E_GOVForMOA.Areas.Admin.Controllers
{
      [LoginRequired]
    public class CustomController : Controller
    {
        //
        // GET: /Admin/Custom/

        public ActionResult Index()
        {


            E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv srv = new E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv();


            STATICPAGECONTENT custom = new STATICPAGECONTENT();
            custom = srv.WS_GetStaticPageContentsForScreenID("2");


            if (custom != null)
            {
                return View("Index", custom); ;
            }
            else
                return View();
        }

        [HttpPost]
        [ValidateInput(false)]
        public string Save(STATICPAGECONTENT custom)
        {
            string response = String.Empty;
            E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv srv = new E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv();
            if (custom.GUID == null)
            {
                custom.SCREEN_GUID = "2";
                custom.GUID = Utility.getGuid();
                response = srv.WS_AddStaticPageContent(custom);
            }
            else
            {
                response = srv.WS_UpdateStaticPageContent(custom);
            }
            return response;
        }


        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Get()
        {
            E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv srv = new E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv();


            STATICPAGECONTENT custom = new STATICPAGECONTENT();
            custom = srv.WS_GetStaticPageContentsForScreenID("2");

            return View("Index", custom);
        }

    }
}
