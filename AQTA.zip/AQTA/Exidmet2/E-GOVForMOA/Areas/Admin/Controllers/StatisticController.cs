﻿using E_GOVForMOA.Areas.Admin.Libraries;
using E_GOVForMOA.EGOVForMOAWbService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace E_GOVForMOA.Areas.Admin.Controllers
{
      [LoginRequired]
    public class StatisticController : Controller
    {
        //
        // GET: /Admin/Statistic/
        public ActionResult Index()
        {


            E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv srv = new E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv();


            STATICPAGECONTENT statistic = new STATICPAGECONTENT();
            statistic = srv.WS_GetStaticPageContentsForScreenID("5");


            if (statistic != null)
            {
                return View("Index", statistic); ;
            }
            else
                return View();
        }

        [HttpPost]
        [ValidateInput(false)]
        public string Save(STATICPAGECONTENT statistic)
        {
            string response = String.Empty;
            E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv srv = new E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv();
            if (statistic.GUID == null)
            {
                statistic.SCREEN_GUID = "5";
                statistic.GUID = Utility.getGuid();
                response = srv.WS_AddStaticPageContent(statistic);
            }
            else
            {
                response = srv.WS_UpdateStaticPageContent(statistic);
            }
            return response;
        }


        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Get()
        {
            E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv srv = new E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv();


            STATICPAGECONTENT statistic = new STATICPAGECONTENT();
            statistic = srv.WS_GetStaticPageContentsForScreenID("4");

            return View("Index", statistic);
        }

    }
}
