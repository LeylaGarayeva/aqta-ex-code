﻿using E_GOVForMOA.Areas.Admin.Libraries;
using E_GOVForMOA.EGOVForMOAWbService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace E_GOVForMOA.Areas.Admin.Controllers
{
          [LoginRequired]
    public class TarifController : Controller
    {
        //
        // GET: /Admin/Tariff/


        public ActionResult Index()
        {


            E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv srv = new E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv();


            STATICPAGECONTENT tarif = new STATICPAGECONTENT();
            tarif = srv.WS_GetStaticPageContentsForScreenID("3");


            if (tarif != null)
            {
                return View("Index", tarif); ;
            }
            else
                return View();
        }

        [HttpPost]
        [ValidateInput(false)]
        public string Save(STATICPAGECONTENT tarif)
        {
            string response = String.Empty;
            E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv srv = new E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv();
            if (tarif.GUID == null)
            {
                tarif.SCREEN_GUID = "3";
                tarif.GUID = Utility.getGuid();
                response = srv.WS_AddStaticPageContent(tarif);
            }
            else
            {
                response = srv.WS_UpdateStaticPageContent(tarif);
            }
            return response;
        }


        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Get()
        {
            E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv srv = new E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv();


            STATICPAGECONTENT tarif = new STATICPAGECONTENT();
            tarif = srv.WS_GetStaticPageContentsForScreenID("3");

            return View("Index", tarif);
        }


    }
}
