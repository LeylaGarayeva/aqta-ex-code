﻿using E_GOVForMOA.Areas.Admin.Libraries;
using E_GOVForMOA.Areas.Admin.ViewModels;
using E_GOVForMOA.EGOVForMOAWbService;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace E_GOVForMOA.Areas.Admin.Controllers
{
      [LoginRequired]
    public class DynamicPageContentController : Controller
    {
        //
        // GET: /Admin/DynamicPageContent/


        E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv srv = new E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv();

       
        public ActionResult Index(PageContentViewModel pcmodel)
        {
            pcmodel.ScrenTypes.Add(new SelectListItem { Text = "-Ekran seç-", Value = "9987787" });
           
            pcmodel.Tites.Add(new SelectListItem { Text = "-Başlık seç-", Value = "" });


            var sreens = srv.WS_GetScreenTypes();
            foreach (var screen in sreens)
            {
                pcmodel.ScrenTypes.Add(new SelectListItem()
                {

                    Text = screen.SCREEN_NAME,
                    Value = screen.GUID.ToString()
                });
            }
            pcmodel._contentInPageList = srv.WS_GetPageContents();
            return View(pcmodel);
        }

      
        [HttpPost]
        [ValidateAntiForgeryToken]
        public void addClientFiles(PageContentViewModel _contentInPage, IEnumerable<HttpPostedFileBase> files)
        {
            string filePath = String.Empty;
            if (files != null)
            {
                foreach (var file in files)
                {
                    // Verify that the user selected a file
                    if (file != null && file.ContentLength > 0)
                    {
                        // extract only the fielname
                        var fileName = Path.GetFileName(file.FileName);
                        // TODO: need to define destination
                        var path = Path.Combine(Server.MapPath("~/ClientFiles"), fileName);
                        filePath = path;
                        file.SaveAs(path);
                    }
                }
            }

            if (_contentInPage != null)
            {

                CONTENTLINKSINPAGE pageContent = new CONTENTLINKSINPAGE();
                pageContent.GUID = Utility.getGuid();
                pageContent.SCREEN_GUID = _contentInPage.ScreenID;
                pageContent.TITLEGUID = _contentInPage.TitleID;
                pageContent.DESCRIPTION = _contentInPage.description;
                pageContent.CONTENT_LINK = filePath;
                pageContent.INSERT_DATE = Utility.getInsetDate();
                pageContent.STATUS = 1;
                pageContent.STATUSSpecified = true;
                pageContent.LASTUPDATED = "1";

                srv.WS_AddPageContent(pageContent);


                _contentInPage._contentInPageList = srv.WS_GetPageContents();

            }
        }
           
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult GetTitleByScreenId(string screenGuid)
        {
            if (String.IsNullOrEmpty(screenGuid))
            {
                screenGuid = "0";
            }

            var titles = srv.WS_GetPageTitlesForScreenID(screenGuid);



            List<SelectListItem> titlelist1 = new List<SelectListItem>();
            titlelist1.Add(new SelectListItem { Text = "-Başlıq seç-", Value = "" });
            List<SelectListItem> titlelist2 = new List<SelectListItem>();

            foreach (var t in titles)
            {
                titlelist2.Add(new SelectListItem()
                {
                    Value = t.GUID.ToString(),
                    Text = t.TITLE,

                });
            }

            List<SelectListItem> resultold = titlelist1.Concat(titlelist2).ToList();

            var result = (from s in resultold
                          select new
                          {
                              id = s.Value,
                              name = s.Text
                          }).ToList();




           
           
            return Json(result, JsonRequestBehavior.AllowGet);

        }

        [HttpPost]
        public string deletePageContent(string guid)
        {
            try
            {


                PageContentViewModel pageContentWM = new PageContentViewModel();
                CONTENTLINKSINPAGE cp = new CONTENTLINKSINPAGE();

                if (!String.IsNullOrEmpty(guid))
                {
                    cp.GUID = guid;
                    srv.WS_DeletePageContent(cp);
                    pageContentWM._contentInPageList = srv.WS_GetPageContents();

                }
                return "1";
            }
            catch (Exception ex)
            {

                return "-1";
            }
        }

        
    }
}
