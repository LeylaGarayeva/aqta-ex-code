﻿using E_GOVForMOA.Areas.Admin.Models;
using E_GOVForMOA.EGOVForMOAWbService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace E_GOVForMOA.Areas.Admin.Controllers
{
    public class AccountController : Controller
    {
        //
        // GET: /Admin/Account/
        E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv srv = new E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv();
        public ActionResult Login()
        {
            var model = new UserIdentification();
            return View(model);
        }

     
        [HttpPost]
        public ActionResult Login(UserIdentification model)
        {
            //burda bir kontrol yapilacak veritabnina baglanib dogrusa sessina yukleyib gondereceyik


            if (ModelState.IsValid)
            {
                USERS  user = srv.WS_CheckUser(model);

                if (user!=null)
                {
                    Session["User"] = user.LOGIN;
                    return RedirectToAction("Index","Home");
                }
                return View(model);
            }
            else {
                return View(model);
            }
            // ok ise ana sayfaya gedecek 
           
        }

      
        public ActionResult Logout()
        {
            //burda bir kontrol yapilacak veritabnina baglanib dogrusa sessina yukleyib gondereceyik

            Session.Clear();
             return RedirectToAction("Login", "Account");
               

        }
    }
}
