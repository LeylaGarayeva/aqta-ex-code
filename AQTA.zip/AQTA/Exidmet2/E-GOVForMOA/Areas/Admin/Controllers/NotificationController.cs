﻿using E_GOVForMOA.Areas.Admin.Libraries;
using E_GOVForMOA.EGOVForMOAWbService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace E_GOVForMOA.Areas.Admin.Controllers
{
      [LoginRequired]
    public class NotificationController : Controller
    {
        //
        // GET: /Admin/Notification/
           
        public ActionResult Index()
        {


            E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv srv = new E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv();


            STATICPAGECONTENT notification = new STATICPAGECONTENT();
            notification = srv.WS_GetStaticPageContentsForScreenID("5");


            if (notification != null)
            {
                return View("Index", notification); ;
            }
            else
            return View();
        }
          
        [HttpPost]
        [ValidateInput(false)]
        public string Save(STATICPAGECONTENT notification)
        {
            string response = String.Empty;
            E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv srv = new E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv();
            if (notification.GUID == null)
            {

                notification.GUID = Utility.getGuid();
                response = srv.WS_AddStaticPageContent(notification);
            }
            else
            {
                response = srv.WS_UpdateStaticPageContent(notification);
            }
            return response;
        }

      
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Get()
        {
            E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv srv = new E_GOVForMOA.EGOVForMOAWbService.EGOVForMOASrv();


            STATICPAGECONTENT notification = new STATICPAGECONTENT();
            notification = srv.WS_GetStaticPageContentsForScreenID("5");

            return View("Index", notification); 
        }

    }
}
