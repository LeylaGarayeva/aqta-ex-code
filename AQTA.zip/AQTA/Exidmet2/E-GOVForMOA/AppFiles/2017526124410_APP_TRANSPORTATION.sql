SET DEFINE OFF;
Insert into OC_MOA.PRM_TECHNIC
   (ID, STATUS, INSERTDATE, NAME, PARENT_ID, 
    TYPE)
 Values
   ('1', 1, TO_DATE('11/09/2016 21:09:16', 'MM/DD/YYYY HH24:MI:SS'), 'Kombayn', '0', 
    '1');
Insert into OC_MOA.PRM_TECHNIC
   (ID, STATUS, INSERTDATE, NAME, PARENT_ID, 
    TYPE)
 Values
   ('2', 1, TO_DATE('11/09/2016 21:09:47', 'MM/DD/YYYY HH24:MI:SS'), 'Ekskavator', '0', 
    '1');
Insert into OC_MOA.PRM_TECHNIC
   (ID, STATUS, INSERTDATE, NAME, PARENT_ID, 
    TYPE)
 Values
   ('3', 1, TO_DATE('11/09/2016 21:10:26', 'MM/DD/YYYY HH24:MI:SS'), 'Traktor Yed?kl?ri', '0', 
    '1');
Insert into OC_MOA.PRM_TECHNIC
   (ID, STATUS, INSERTDATE, NAME, PARENT_ID, 
    TYPE)
 Values
   ('4', 1, TO_DATE('11/09/2016 21:10:41', 'MM/DD/YYYY HH24:MI:SS'), 'Kotan', '0', 
    '1');
Insert into OC_MOA.PRM_TECHNIC
   (ID, STATUS, INSERTDATE, NAME, PARENT_ID, 
    TYPE)
 Values
   ('5', 1, TO_DATE('11/09/2016 21:11:23', 'MM/DD/YYYY HH24:MI:SS'), 'Mala ', '0', 
    '1');
Insert into OC_MOA.PRM_TECHNIC
   (ID, STATUS, INSERTDATE, NAME, PARENT_ID, 
    TYPE)
 Values
   ('12', 1, TO_DATE('11/16/2016 13:55:06', 'MM/DD/YYYY HH24:MI:SS'), 'Dig?r texnika', '0', 
    '1');
Insert into OC_MOA.PRM_TECHNIC
   (ID, STATUS, INSERTDATE, NAME, PARENT_ID, 
    TYPE)
 Values
   ('11', 1, TO_DATE('11/16/2016 13:54:52', 'MM/DD/YYYY HH24:MI:SS'), 'Ot presl?y?n', '0', 
    '1');
Insert into OC_MOA.PRM_TECHNIC
   (ID, STATUS, INSERTDATE, NAME, PARENT_ID, 
    TYPE)
 Values
   ('10', 1, TO_DATE('11/16/2016 13:54:37', 'MM/DD/YYYY HH24:MI:SS'), 'Otbi�?n', '0', 
    '1');
Insert into OC_MOA.PRM_TECHNIC
   (ID, STATUS, INSERTDATE, NAME, PARENT_ID, 
    TYPE)
 Values
   ('9', 1, TO_DATE('11/16/2016 13:54:05', 'MM/DD/YYYY HH24:MI:SS'), '�il?yici', '0', 
    '1');
Insert into OC_MOA.PRM_TECHNIC
   (ID, STATUS, INSERTDATE, NAME, PARENT_ID, 
    TYPE)
 Values
   ('8', 1, TO_DATE('11/16/2016 13:53:31', 'MM/DD/YYYY HH24:MI:SS'), 'Kultivator', '0', 
    '1');
Insert into OC_MOA.PRM_TECHNIC
   (ID, STATUS, INSERTDATE, NAME, PARENT_ID, 
    TYPE)
 Values
   ('7', 1, TO_DATE('11/16/2016 13:53:26', 'MM/DD/YYYY HH24:MI:SS'), 'G�br?s?p?n', '0', 
    '1');
Insert into OC_MOA.PRM_TECHNIC
   (ID, STATUS, INSERTDATE, NAME, PARENT_ID, 
    TYPE)
 Values
   ('13', 1, TO_DATE('11/16/2016 13:55:41', 'MM/DD/YYYY HH24:MI:SS'), 'G?nc? traktoru', '0', 
    '1');
Insert into OC_MOA.PRM_TECHNIC
   (ID, STATUS, INSERTDATE, NAME, PARENT_ID, 
    TYPE)
 Values
   ('14', 1, TO_DATE('11/16/2016 13:55:54', 'MM/DD/YYYY HH24:MI:SS'), 'Pambiq yigan kombayn', '0', 
    '1');
Insert into OC_MOA.PRM_TECHNIC
   (ID, STATUS, INSERTDATE, NAME, PARENT_ID, 
    TYPE)
 Values
   ('15', 1, TO_DATE('11/16/2016 13:56:16', 'MM/DD/YYYY HH24:MI:SS'), 'Texnoloji avadanliqlar', '0', 
    '1');
Insert into OC_MOA.PRM_TECHNIC
   (ID, STATUS, INSERTDATE, NAME, PARENT_ID, 
    TYPE)
 Values
   ('6', 1, TO_DATE('11/09/2016 21:11:38', 'MM/DD/YYYY HH24:MI:SS'), 'Toxums?p?n', '0', 
    '1');
COMMIT;
